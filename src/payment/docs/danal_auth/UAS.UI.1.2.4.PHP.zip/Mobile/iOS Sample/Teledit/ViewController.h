//
//  ViewController.h
//  Teledit
//
//  Created by User on 2017. 5. 18..
//  Copyright © 2017년 danal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

