//
//  AppDelegate.h
//  Teledit
//
//  Created by User on 2017. 5. 18..
//  Copyright © 2017년 danal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

