//
//  ViewController.m
//  Teledit
//
//  Created by User on 2017. 5. 18..
//  Copyright © 2017년 danal. All rights reserved.
//

#import "ViewController.h"

#warning 해당 페이지 주소로 변경하세요
#define DanalTeleditMobileUrl @"http://[가맹점웹서버]/Mobie/Ready.php"
#define DanalTeleditInAppUrl @"http://[가맹점웹서버]/InApp/Ready.php"

@interface ViewController () <UIWebViewDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:DanalTeleditInAppUrl]];
    [self.webView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark - Webview Delegate
/**
 * 웹페이지 리퀘스트 요청 시작
 */
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSURL    *requestedURL = [request URL];
    NSString *receivedLink = requestedURL.absoluteString;
    NSLog(@"Should Request::: %@", receivedLink);
    
    /**
     * 휴대폰 인증 완료 후 결과값 전달 받기
     */
    if ([receivedLink containsString:@"teleditapp:Result:"]) {
        NSString *result = [receivedLink stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"알림"
                                                        message:result
                                                       delegate:self
                                              cancelButtonTitle:@"취소"
                                              otherButtonTitles:@"확인",nil];
        
        [alert show];
        
    }
    
    /**
     * Mobile WebPage에서 JavaScript funtion이 호출되면 닫기 처리
     */
    if ([receivedLink containsString:@"teleditapp:BestClose"]) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
    return YES;
}

/**
 * 웹페이지 로딩 시작
 */
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

/**
 * 웹페이지 로딩 종료
 */
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

/**
 * 웹페이지 로딩 중 오류
 */
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    NSLog(@"Load Fail - 내용: %@", [error localizedDescription]);
    
    // NSURLErrorDomain error -999 무시하기.
    if (error.code == NSURLErrorCancelled) return;
}


@end
